package bai3;

import java.io.IOException;
import javax.servlet.*;

public class TempFilter implements Filter {
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        String temp = request.getParameter("temperature");

        try {
            Double.parseDouble(temp);
            chain.doFilter(request, response);
        } catch (NumberFormatException | NullPointerException e) {
            request.setAttribute("result", "Nhiệt độ phải là số hợp lệ!");
            request.getRequestDispatcher("temp.jsp").forward(request, response);
        }
    }

    public void init(FilterConfig filterConfig) {}
    public void destroy() {}
}
