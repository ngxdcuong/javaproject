package bai3;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class TemperatureServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String tempStr = request.getParameter("temperature");
        String type = request.getParameter("type");

        double result = 0;
        String output = "";

        try {
            double temp = Double.parseDouble(tempStr);
            if ("c2f".equals(type)) {
                result = temp * 9 / 5 + 32;
                output = temp + " °C = " + result + " °F";
            } else if ("f2c".equals(type)) {
                result = (temp - 32) * 5 / 9;
                output = temp + " °F = " + result + " °C";
            }
        } catch (NumberFormatException e) {
            output = "Giá trị không hợp lệ!";
        }

        request.setAttribute("result", output);
        RequestDispatcher dispatcher = request.getRequestDispatcher("temp.jsp");
        dispatcher.forward(request, response);
    }
}
